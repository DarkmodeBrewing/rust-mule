rust-mule Linux release bundle

Run:
  ./rust-mule

Config:
  rust-mule reads ./config.toml from the current working directory.
  Copy config.example.toml -> config.toml and edit as needed.

Data:
  Runtime state is written under [general].data_dir (default: data/).
